#ifndef __RELAY_H
#define __RELAY_H

#define RELAY_PIN PAout(1)
#define R_RELAY_PIN GPIO_ReadInputDataBit(GPIOA,GPIO_Pin_1)//��ȡ����0

void init_relay(void);


#endif


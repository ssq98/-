#ifndef __HS501_H
#define __HS501_H

#define HS501_PIN		PAout(0)
#define R_HS501_PIN  GPIO_ReadInputDataBit(GPIOA,GPIO_Pin_0)//��ȡ����0

void init_HS501(void);
void EXTI0_IRQHandler(void);

#endif


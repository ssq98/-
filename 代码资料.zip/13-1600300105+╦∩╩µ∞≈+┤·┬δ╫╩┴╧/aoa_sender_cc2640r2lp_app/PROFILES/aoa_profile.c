/******************************************************************************

 @file       aoa_profile.c

 @brief This file contains the AOA Profile for use with the CC2650 Bluetooth 
        Low Energy Protocol Stack.

 Group: CMCU, SCS
 Target Device: CC2640R2

 ******************************************************************************
 
 Copyright (c) 2018-2018, Texas Instruments Incorporated
 All rights reserved.

 Redistribution and use in source and binary forms, with or without
 modification, are permitted provided that the following conditions
 are met:

 *  Redistributions of source code must retain the above copyright
    notice, this list of conditions and the following disclaimer.

 *  Redistributions in binary form must reproduce the above copyright
    notice, this list of conditions and the following disclaimer in the
    documentation and/or other materials provided with the distribution.

 *  Neither the name of Texas Instruments Incorporated nor the names of
    its contributors may be used to endorse or promote products derived
    from this software without specific prior written permission.

 THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO,
 THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR
 PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR
 CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
 EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,
 PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS;
 OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY,
 WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR
 OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE,
 EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

 ******************************************************************************
 Release Name: simplelink_cc2640r2_sdk_02_30_00_28
 Release Date: 2018-10-15 15:51:38
 *****************************************************************************/

/*********************************************************************
 * INCLUDES
 */

/* This Header file contains all BLE API and icall structure definition */
#include "icall_ble_api.h"

#include <aoa_profile.h>

/*********************************************************************
 * MACROS
 */

/*********************************************************************
 * CONSTANTS
 */


/*********************************************************************
 * EXTERNAL VARIABLES
 */

/*********************************************************************
 * EXTERNAL FUNCTIONS
 */

/*********************************************************************
 * LOCAL VARIABLES
 */

aoaProfileServiceCB_t aoaProfileServiceCB = NULL;

// AOA Service UUID
static CONST uint8 aoaServUUID[ATT_BT_UUID_SIZE] =
{
  LO_UINT16(AOAPROFILE_SERVICE_UUID),
  HI_UINT16(AOAPROFILE_SERVICE_UUID)
};

// AOA Attribute UUIDs
// Master will decide when to start sending packets
static CONST uint8 aoaStartUUID[ATT_BT_UUID_SIZE] =
{
  LO_UINT16(AOAPROFILE_AOA_START_UUID),
  HI_UINT16(AOAPROFILE_AOA_START_UUID)
};



/*********************************************************************
 * Profile Attributes - variables
 */
/*********************************************************************
 * Profile Attributes - variables
 */

// AOA Service attribute
static const gattAttrType_t aoaService = { ATT_BT_UUID_SIZE, aoaServUUID };

// AOA Variables
static uint8_t aoaStart = 0;

// AOA Characteristic Properties
static uint8_t aoaCharProps = GATT_PROP_READ | GATT_PROP_WRITE;

// AOA Client Characteristic Configs
static gattCharCfg_t *aoaStartConfig;


/*********************************************************************
 * Profile Attributes - Table
 */

static gattAttribute_t aoaAttrTbl[] =
{
  // AOA Service
  {
    { ATT_BT_UUID_SIZE, primaryServiceUUID },
    GATT_PERMIT_READ,
    0,
    (uint8_t *)&aoaService
  },

    //////////////////////////////////////////////
    // AoA Start/Stop
    //////////////////////////////////////////////

    // Characteristic Declaration
    {
      { ATT_BT_UUID_SIZE, characterUUID },
      GATT_PERMIT_READ,
      0,
      &aoaCharProps
    },

    // Characteristic Value
    {
      { ATT_BT_UUID_SIZE, aoaStartUUID },
      GATT_PERMIT_READ | GATT_PERMIT_WRITE,
      0,
      (uint8_t *)&aoaStart
    }
};

/*********************************************************************
 * LOCAL FUNCTIONS
 */
static bStatus_t aoaProfile_WriteAttrCB(uint16_t connHandle,
                                        gattAttribute_t *pAttr,
                                        uint8_t *pValue, uint16_t len,
                                        uint16_t offset, uint8_t method);

/*********************************************************************
 * PROFILE CALLBACKS
 */
// AOA Profile Service Callbacks
// Note: When an operation on a characteristic requires authorization and
// pfnAuthorizeAttrCB is not defined for that characteristic's service, the
// Stack will report a status of ATT_ERR_UNLIKELY to the client.  When an
// operation on a characteristic requires authorization the Stack will call
// pfnAuthorizeAttrCB to check a client's authorization prior to calling
// pfnReadAttrCB or pfnWriteAttrCB, so no checks for authorization need to be
// made within these functions.
static CONST gattServiceCBs_t aoaProfileCBs =
{
  NULL,  // Read callback function pointer.
  aoaProfile_WriteAttrCB, // Write callback function pointer.
  NULL                    // Authorization callback function pointer.
};

/*********************************************************************
 * PUBLIC FUNCTIONS
 */

/*********************************************************************
 * @fn      AOAProfile_AddService
 *
 * @brief   Initializes the AOA Profile service by registering
 *          GATT attributes with the GATT server.
 *
 * @param   services - services to add. This is a bit map and can
 *                     contain more than one service.
 *
 * @return  Success or Failure
 */
bStatus_t AOAProfile_AddService(uint32 services)
{
  uint8 status;
   
  // Allocate Client Characteristic Configuration table
  aoaStartConfig = (gattCharCfg_t *)ICall_malloc(sizeof(gattCharCfg_t)* linkDBNumConns);
  
  if (aoaStartConfig == NULL)
  {
    // Free already allocated data
    ICall_free(aoaStartConfig);
    aoaStartConfig = NULL;
    return (bleMemAllocError);
  }

  // Initialize Client Characteristic Configuration attributes.
  GATTServApp_InitCharCfg(INVALID_CONNHANDLE, aoaStartConfig);


  // Register GATT attribute list and CBs with GATT Server App.
  status = GATTServApp_RegisterService(aoaAttrTbl,
                                       GATT_NUM_ATTRS(aoaAttrTbl),
                                       GATT_MAX_ENCRYPT_KEY_SIZE,
                                       &aoaProfileCBs);

  return (status);
}


                       
/*********************************************************************
 * @fn      aoaProfile_WriteAttrCB
 *
 * @brief   Validate attribute data prior to a write operation
 *
 * @param   connHandle - connection message was received on
 * @param   pAttr - pointer to attribute
 * @param   pValue - pointer to data to be written
 * @param   len - length of data
 * @param   offset - offset of the first octet to be written
 * @param   method - type of write message
 *
 * @return  SUCCESS, blePending or Failure
 */
static bStatus_t aoaProfile_WriteAttrCB(uint16_t connHandle, 
                                        gattAttribute_t *pAttr,
                                        uint8_t *pValue, uint16_t len,
                                        uint16_t offset, uint8_t method)
{
  uint16_t uuid;
  bStatus_t status = SUCCESS;

  // Only allow 16 bit UUIDs
  if (pAttr->type.len != ATT_BT_UUID_SIZE)
  {
    return (ATT_ERR_INVALID_HANDLE);
  }

  uuid = BUILD_UINT16(pAttr->type.uuid[0], pAttr->type.uuid[1]);

  switch (uuid)
  {
    case AOAPROFILE_AOA_START_UUID:
      {
        aoaStart = *pValue;
        aoaProfileServiceCB(AOAPROFILE_AOA_START); // Call application callback
      }
      break;

    default:
      status = ATT_ERR_ATTR_NOT_FOUND;
      break;
  }

  return (status);
}


/*********************************************************************
 * @fn      AOAProfile_GetParameter - Get a parameter.
 *
 * @param   param - Profile parameter ID
 * @param   pValue - pointer to data to write.  This is dependent on
 *          the parameter ID and WILL be cast to the appropriate
 *          data type (example: data type of uint16 will be cast to
 *          uint16 pointer).
 *
 * @return  bStatus_t
 */
bStatus_t AOAProfile_GetParameter(uint8 param, void *pValue)
{
  bStatus_t ret = SUCCESS;

  switch (param)
  {
    case AOAPROFILE_AOA_START:
      *((uint8_t *)pValue) = aoaStart;
      break;

    default:
      ret = INVALIDPARAMETER;
      break;
  }

  return (ret);
}


/*********************************************************************
 * @fn      AOAProfile_SetParameter - Set a parameter.
 *
 * @param   param - Profile parameter ID
 * @param   pValue - pointer to data to write.  This is dependent on
 *          the parameter ID and WILL be cast to the appropriate
 *          data type (example: data type of uint16 will be cast to
 *          uint16 pointer).
 *
 * @return  bStatus_t
 */
bStatus_t AOAProfile_SetParameter(uint8 param, void *pValue)
{
  bStatus_t ret = SUCCESS;

  switch (param)
  {
    case AOAPROFILE_AOA_START:
    	aoaStart = *((uint8_t *)pValue);
      break;

    default:
      ret = INVALIDPARAMETER;
      break;
  }

  return (ret);
}

void AOAProfile_Register(aoaProfileServiceCB_t pfnProfileCB)
{
  aoaProfileServiceCB = pfnProfileCB;
}

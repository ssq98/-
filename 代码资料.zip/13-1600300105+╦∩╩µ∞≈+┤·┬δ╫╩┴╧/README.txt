1.aoa_receiver_cc2640r2**的文件夹中是接收端工程，环境CCS9.2。需要SDK：simplelink_cc2640r2_sdk_2_30_00_28
2.aoa_sender_cc2640r2**的文件夹中是发射端工程，环境CCS9.2。需要SDK：simplelink_cc2640r2_sdk_2_30_00_28
3.小车代码在小车文件夹中，环境Keil5

注，当前是通信的展示环境代码，小车和CC2640R2F的通信只需要（X，Y）。需要注释Display_Open,取消UART_Init的注释。

遇到问题联系QQ：214298128